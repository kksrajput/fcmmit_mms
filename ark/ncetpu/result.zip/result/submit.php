<?php


if(isset($_REQUEST['sub']))
{
	$con = mysqli_connect('103.53.41.210','ncetmmhh_ark','13774');
		if ($con) {
			echo "";
		}

	mysqli_select_db($con,'ncetmmhh_quiz_pcme');

	$name=$_REQUEST['name'];
	
	$phone=$_REQUEST['phone'];

    $percentage=$_REQUEST['percentage'];
    
    $jee=$_REQUEST['jee'];
	
	$Comedk=$_REQUEST['Comedk'];

	$other=$_REQUEST['other'];

	$q = "insert into result(name,  phone, percentage, jee, Comedk, other) values ('$name', '$phone', '$percentage', '$jee', '$Comedk', '$other')";

	mysqli_query($con,$q);


 ?>

	
<!DOCTYPE HTML>
<html>
<head>
<title>NGI | Results</title>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<!--web-fonts-->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'></head>
<link href="//fonts.googleapis.com/css?family=Arvo:400,400i,700,700i" rel="stylesheet">
<!--web-fonts-->
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-73144081-5"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-73144081-5');
</script>

<body>
		<!---header--->
		<div class="header">
			<h1>NGI RESULTS 2020</h1>
		</div>
		<!---header--->
		<!---main--->
			<div class="main-content">
				<div class="contact-w3" >

					
				</div>
			</div>
			
		<div class="footer-w3-agile">
			<p>NGI RESULTS</p>
		</div>

		<!---main--->
</body>
</html>



<?php

}

?>