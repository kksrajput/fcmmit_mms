<!DOCTYPE html>
<html>
<head>
	<title>Create</title>
</head>
<body>
<form action="save.php" method="POST" name="f3">
<b>Enter Problem Name</b><br>
<input type="text" name="pb"><br><br>
<textarea name="c1" rows="10" cols="30"></textarea><br>
<input type="submit" name="Submit">
</form>

</body>
</html>