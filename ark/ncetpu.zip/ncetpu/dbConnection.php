<?php
	$con= new mysqli('216.10.249.126','ncetmons_ark','ARKark@007','ncetmons_quiz_pcme')or die("Could not connect to mysql".mysqli_error($con));
?>